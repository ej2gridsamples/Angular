import { Component, ViewChild, ViewEncapsulation, OnInit, Inject } from '@angular/core';
import { DatePicker } from '@syncfusion/ej2-calendars';
import { DataManager, WebApiAdaptor, UrlAdaptor, RemoteSaveAdaptor } from '@syncfusion/ej2-data';
import { GridComponent } from '@syncfusion/ej2-angular-grids';
import { employeeData, customerData, orderData, orderDatas } from './datasource';
class CustomRemoteSaveAdaptor extends RemoteSaveAdaptor {
    beforeSend(dm: DataManager, request: XMLHttpRequest) {
        debugger;
        const token = 'Basic ';
        dm.dataSource.headers = [{ 'Authorization': token }]; // setting header
    }
}
@Component({
    selector: 'fetchdata',
    templateUrl: './fetchdata.component.html',
    encapsulation: ViewEncapsulation.Emulated
})


export class FetchDataComponent {
    public data: any;
    public value: any;
    public editSettings: Object;
    public toolbar: string[];
   
    ngOnInit(): void {
        this.value = (window as any).griddata;
        this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, newRowPosition: 'Top' };
        this.toolbar = ['Add', 'Edit', 'Delete', 'Update', 'Cancel'];
        this.data = new DataManager({
        json: JSON.parse(this.value),
        updateUrl: "Home/Update",
        insertUrl: "Home/Insert",
        removeUrl: "Home/Delete",
        adaptor: new RemoteSaveAdaptor,
        headers: [{ 'Authorization': 'Basic' }]
    });
  }

}

