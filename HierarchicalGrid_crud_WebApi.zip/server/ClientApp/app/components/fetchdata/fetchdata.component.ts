import { Component, ViewChild, ViewEncapsulation, OnInit, Inject } from '@angular/core';
import { DatePicker } from '@syncfusion/ej2-calendars';
import { DataManager, WebApiAdaptor, UrlAdaptor, RemoteSaveAdaptor, Query } from '@syncfusion/ej2-data';
import { GridComponent, IEditCell, Column, ToolbarItems } from '@syncfusion/ej2-angular-grids';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { employeeData, customerData, orderData, orderDatas } from './datasource';

@Component({
    selector: 'fetchdata',
    templateUrl: './fetchdata.component.html',
    encapsulation: ViewEncapsulation.Emulated
})


export class FetchDataComponent {
    public data: DataManager | Object[];
    public toolbar: ToolbarItems[];
    public editSettings: Object;
    public childGrid: any;
    public secondChildGrid: any;

    @ViewChild('grid')
    public grid: GridComponent;

    ngOnInit(): void {
        this.toolbar = ['Add', 'Edit', 'Delete', 'Update', 'Cancel'];
        this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true };
        this.data = new DataManager({
            url: '/api/Customers',
            adaptor: new WebApiAdaptor
        });
        this.childGrid = {
            dataSource: new DataManager({
                url: '/api/Orders',
                adaptor: new WebApiAdaptor
            }),
            queryString: 'ID',
            allowPaging: true,
            editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true },
            toolbar: ["Add", "Edit", "Delete", "Update", "Cancel"],
            columns: [
                { field: 'CustomerID', headerText: 'Customer ID', isPrimaryKey: true, width: 120 },
                { field: 'ID', headerText: 'Query String', width: 120 },
                { field: 'Name', headerText: 'Name', width: 120 }
            ],
            childGrid: {
                dataSource: new DataManager({
                    url: '/api/CustomerOrdersReturns',
                    adaptor: new WebApiAdaptor
                }),
                queryString: 'CustomerID',
                allowPaging: true,
                editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true },
                toolbar: ["Add", "Edit", "Delete", "Update", "Cancel"],
                columns: [
                    { field: 'OrderID', headerText: 'Order ID', isPrimaryKey: true, width: 100 },
                    { field: 'CustomerID', headerText: 'Query String', width: 120 },
                    { field: 'Id', headerText: 'ID', width: 75 }
                ],
            }
        };
    }
}

