﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AngularwithASPCore.Controllers
{
    [Produces("application/json")]
    [Route("api/Customers")]
    public class CustomersController : Controller
    {
        public static List<CustomersTable> customers = new List<CustomersTable>();
        public static bool flag = true;
        // GET: api/Customers
        [HttpGet]
        public object Get()
        {
            if (customers.Count == 0 && flag)
            {
                flag = false;
                BindDataSource();
            }
            int skip = Convert.ToInt32(HttpContext.Request.Query["$skip"].ToString());
            int take = Convert.ToInt32(HttpContext.Request.Query["$top"].ToString());
            var data = customers.ToList();
            return new { Items = data.Skip(skip).Take(take).ToList(), Count = data.Count() };
        }

        // PUT: api/Customers/5
        [HttpPut]
        public object Put(int id, [FromBody]CustomersTable value)
        {
            var ord = value;
            CustomersTable val = customers.Where(or => or.ID == ord.ID).FirstOrDefault();
            val.ID = ord.ID;
            val.Name = ord.Name;
            return value;
        }

        // POST: api/Customers
        [HttpPost]
        public object Post([FromBody]CustomersTable value)
        {
            customers.Insert(0, value);
            return value;
        }
        
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        [Route("Customers/{id:int}")]
        public void Delete(int id)
        {
            customers.Remove(customers.Where(or => or.ID == id).FirstOrDefault());
        }

        public void BindDataSource()
        {
            customers.Add(new CustomersTable(1, "Davolio"));
            customers.Add(new CustomersTable(2, "Fuller"));
        }
        public class CustomersTable
        {
            public CustomersTable()
            {

            }
            public CustomersTable(int ID, string Name)
            {
                this.ID = ID;
                this.Name = Name;
            }
            public int ID { get; set; }
            public string Name { get; set; }
        }
    }
}
