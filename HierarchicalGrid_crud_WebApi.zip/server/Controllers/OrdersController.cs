﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Threading.Tasks;
using AngularwithASPCore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Syncfusion.EJ2.Base;




namespace AngularwithASPCore.Controllers
{
    [Produces("application/json")]
    [Route("api/Orders")]
    public class OrdersController : Controller
    {
        public static List<Orders> orders = new List<Orders>();
        public static bool flag = true;

        // GET: api/Orders
        [HttpGet]
        public object Get()
        {
            if (orders.Count == 0 && flag)
            {
                flag = false;
                BindDataSource();
            }
            var data = orders.ToList();
            var queryString = HttpContext.Request.Query;
            string filter = queryString["$filter"];  //filtering 
            var filtervalue = Int32.Parse(filter.Split("eq ")[1]);
            if (filter != null)
            {
                data = (from cust in orders
                        where cust.ID == filtervalue
                        select cust).ToList();

            }
            int skip = Convert.ToInt32(HttpContext.Request.Query["$skip"].ToString());
            int take = Convert.ToInt32(HttpContext.Request.Query["$top"].ToString());
            return new { Items = data.Skip(skip).Take(take).ToList(), Count = data.Count() };
        }

        // PUT: api/Orders/5
        [HttpPut]
        public object Put(int id, [FromBody]Orders value)
        {
            var ord = value;
            Orders val = orders.Where(or => or.CustomerID == value.CustomerID).FirstOrDefault();
            val.ID = ord.ID;
            val.CustomerID = ord.CustomerID;
            val.Name = ord.Name;
            val.Total = ord.Total;
            val.WasReturned = ord.WasReturned;
            return value;
        }

        [HttpPost]
        public Object Post([FromBody]Orders value)
        {
            orders.Insert(0, value);
            return value;
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        [Route("Orders/{id:int}")]
        public void Delete(int id)
        {
            orders.Remove(orders.Where(or => or.CustomerID == id).FirstOrDefault());
        }

        public void BindDataSource()
        {
            orders.Add(new Orders(1, "Nancy", 10, 2.3, "Yes"));
            orders.Add(new Orders(2, "Janet", 20, 4.3, "No"));
        }

        public class Data
        {

            public bool requiresCounts { get; set; }
            public int skip { get; set; }
            public int take { get; set; }
        }
        public class CRUDModel<T> where T : class
        {
            public string action { get; set; }

            public string table { get; set; }

            public string keyColumn { get; set; }

            public int key { get; set; }

            public T value { get; set; }

            public List<T> added { get; set; }

            public List<T> changed { get; set; }

            public List<T> deleted { get; set; }

            public IDictionary<string, object> @params { get; set; }
        }

        public class Orders
        {
            public Orders()
            {

            }
            public Orders(int ID, string Name, int CustomerID, double Total, string WasReturned)
            {
                this.ID = ID;
                this.Name = Name;
                this.CustomerID = CustomerID;
                this.Total = Total;
                this.WasReturned = WasReturned;
            }
            public int ID { get; set; }
            public string Name { get; set; }
            public int CustomerID { get; set; }
            public double Total { get; set; }
            public string WasReturned { get; set; }
        }
    }
}
