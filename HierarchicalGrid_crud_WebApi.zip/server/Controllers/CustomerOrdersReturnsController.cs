﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AngularwithASPCore.Controllers
{
    [Produces("application/json")]
    [Route("api/CustomerOrdersReturns")]
    public class CustomerOrdersReturnsController : Controller
    {
        public static List<CustomerOrdersReturnsTable> orderreturns = new List<CustomerOrdersReturnsTable>();
        public static bool flag = true;

        // GET: api/CustomerOrdersReturns
        [HttpGet]
        public object Get()
        {
            if (orderreturns.Count == 0 && flag)
            {
                flag = false;
                BindDataSource();
            }
            var data = orderreturns.ToList();
            var queryString = HttpContext.Request.Query;
            string filter = queryString["$filter"];  //filtering 
            var filtervalue = Int32.Parse(filter.Split("eq ")[1]);
            if (filter != null)
            {
                data = (from cust in orderreturns
                        where cust.CustomerID == filtervalue
                        select cust).ToList();

            }
            int skip = Convert.ToInt32(HttpContext.Request.Query["$skip"].ToString());
            int take = Convert.ToInt32(HttpContext.Request.Query["$top"].ToString());
            return new { Items = data.Skip(skip).Take(take).ToList(), Count = data.Count() };
        }

        // PUT: api/CustomerOrdersReturns/5
        [HttpPut]
        public object Put(int id, [FromBody]CustomerOrdersReturnsTable value)
        {
            var ord = value;
            CustomerOrdersReturnsTable val = orderreturns.Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
            val.OrderID = ord.OrderID;
            val.Id = ord.Id;
            val.OrderAmount = ord.OrderAmount;
            val.CustomerID = ord.CustomerID;
            return value;
        }

        // POST: api/CustomerOrdersReturns
        [HttpPost]
        public object Post([FromBody]CustomerOrdersReturnsTable value)
        {
            orderreturns.Insert(0, value);
            return value;
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        [Route("CustomerOrdersReturns/{id:int}")]
        public void Delete(int id)
        {
            orderreturns.Remove(orderreturns.Where(or => or.OrderID == id).FirstOrDefault());
        }
        public void BindDataSource()
        {
            orderreturns.Add(new CustomerOrdersReturnsTable(100, 10248, 10, 34));
            orderreturns.Add(new CustomerOrdersReturnsTable(200, 10250, 20, 25));
        }
        public class CustomerOrdersReturnsTable
        {
            public CustomerOrdersReturnsTable()
            {

            }
            public CustomerOrdersReturnsTable(int Id, int OrderID, int CustomerID, double OrderAmount)
            {
                this.Id = Id;
                this.OrderID = OrderID;
                this.CustomerID = CustomerID;
                this.OrderAmount = OrderAmount;
            }
            public int Id { get; set; }
            public int OrderID { get; set; }
            public int CustomerID { get; set; }
            public double OrderAmount { get; set; }
        }
    }
}
