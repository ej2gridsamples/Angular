import { Component, ViewChild, ViewEncapsulation, OnInit, Inject } from '@angular/core';
import { DatePicker } from '@syncfusion/ej2-calendars';
import { Column, EditSettingsModel, ToolbarItems, IEditCell } from '@syncfusion/ej2-angular-grids';
import { DataManager, WebApiAdaptor, UrlAdaptor } from '@syncfusion/ej2-data';
import { SaveEventArgs, IRow } from '@syncfusion/ej2-grids';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { GridComponent } from '@syncfusion/ej2-angular-grids';
import { employeeData, customerData, orderData, orderDatas } from './datasource';

@Component({
    selector: 'fetchdata',
    templateUrl: './fetchdata.component.html',
    encapsulation: ViewEncapsulation.Emulated
})
export class FetchDataComponent {
    public data: any;
    public editSettings: Object;
    public toolbar: string[];
    public filterSettings: Object;
  @ViewChild('grid')
  public grid: GridComponent;

    ngOnInit(): void {
        this.filterSettings = { type: 'Excel' };
        this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Dialog' };
        this.toolbar = ['Add', 'Edit', 'Delete'];
    this.data = new DataManager({
        url: 'api/Orders/DataSource',
        insertUrl: "api/Orders/Insert",
        updateUrl: "api/Orders/Update",
        removeUrl: "api/Orders/Delete",
        adaptor: new UrlAdaptor
    });
  }

    actionBegin( args : any) {
        if (args.requestType === "filterchoicerequest") {
            let filterfields = [];
            let objFilter = Object.keys(args.filterModel.existingPredicate);
            for (let i = 0; i < objFilter.length; i++) {
                filterfields.push(objFilter[i]);
            }
            filterfields.push(args.filterModel.options.field);
            args.query.distincts = [];
            args.query.select(filterfields); // Created the select query 
        } 

    }

}

