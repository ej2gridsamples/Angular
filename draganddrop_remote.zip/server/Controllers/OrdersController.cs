﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AngularwithASPCore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AngularwithASPCore.Controllers
{
    [Produces("application/json")]
    [Route("api/Orders")]
    public class OrdersController : Controller
    {
        // GET: api/Orders
        [HttpGet]

        public object Get()
        {
            var queryString = Request.Query;
            var data = OrdersDetails.GetAllRecords().ToList();
            string sort = queryString["$orderby"];   //sorting     
            string filter = queryString["$filter"];
            if (sort != null) //Sorting
            {
                switch (sort)
                {
                    case "OrderID":
                        if (sort.Substring(sort.IndexOf(' ') + 1) != null)
                            data = data.OrderByDescending(x => x.OrderID).ToList();
                        else
                            data = data.OrderBy(x => x.OrderID).ToList();
                        break;
                    case "CustomerID":
                        if (sort.Substring(sort.IndexOf(' ') + 1) != null)
                            data = data.OrderByDescending(x => x.CustomerID).ToList();
                        else
                            data = data.OrderBy(x => x.CustomerID).ToList();
                        break;
                    case "ShipCity":
                        if (sort.Substring(sort.IndexOf(' ') + 1) != null)
                            data = data.OrderByDescending(x => x.ShipCity).ToList();
                        else
                            data = data.OrderBy(x => x.ShipCity).ToList();
                        break;
                }
            }
            if (filter != null)
            {
                var newfiltersplits = filter;
                var filtersplits = newfiltersplits.Split('(', ')', ' ');
                var filterfield = filtersplits[1];
                var filtervalue = filtersplits[3];
                if (filtersplits.Length != 5)
                {
                    filterfield = filter.Split('(', ')', '\'')[3];
                    filtervalue = filter.Split('(', ')', '\'')[5];
                }
                switch (filterfield)
                {


                    case "OrderID":

                        data = (from cust in data
                                where cust.OrderID.ToString() == filtervalue.ToString()
                                select cust).ToList();
                        break;
                    case "CustomerID":
                        data = (from cust in data
                                where cust.CustomerID.ToLower().StartsWith(filtervalue.ToString())
                                select cust).ToList();
                        break;
                    case "ShipCity":
                        data = (from cust in data
                                where cust.ShipCity.ToLower().StartsWith(filtervalue.ToString())
                                select cust).ToList();
                        break;
                }
            }

            int skip = Convert.ToInt32(queryString["$skip"]);
            int take = Convert.ToInt32(queryString["$top"]);
            return take != 0 ? new { Items = data.Skip(skip).Take(take).ToList(), Count = data.Count() } : new { Items = data, Count = data.Count() };
        }
        
        
        // GET: api/Orders/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Orders/Move
        [HttpPost]
        [Route("Move")]
        public void Move([FromBody] data data)
        {
            var tmp = OrdersDetails.GetAllRecords()[data.oldIndex];
            OrdersDetails.GetAllRecords()[data.oldIndex] = OrdersDetails.GetAllRecords()[data.newIndex];
            OrdersDetails.GetAllRecords()[data.newIndex] = tmp;
        }

        public class data
        {
            public int oldIndex { get; set; }
            public int newIndex { get; set; }
        }

        // POST: api/Orders
        [HttpPost]
        public object Post([FromBody]OrdersDetails value)
        {
            OrdersDetails.GetAllRecords().Insert(0, value);
            var data = OrdersDetails.GetAllRecords().ToList();
            return Json(new { result = data, count = data.Count });
        }


        // PUT: api/Orders/5
        [HttpPut]
        public object Put(int id, [FromBody]OrdersDetails value)
        {


            var ord = value;
            OrdersDetails val = OrdersDetails.GetAllRecords().Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
            val.OrderID = ord.OrderID;
            val.EmployeeID = ord.EmployeeID;
            val.CustomerID = ord.CustomerID;
            val.Freight = ord.Freight;
            val.OrderDate = ord.OrderDate;
            val.ShipCity = ord.ShipCity;
            return value;
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id:int}")]
        [Route("Orders/{id:int}")]
        public object Delete(int id)
        {
            OrdersDetails.GetAllRecords().Remove(OrdersDetails.GetAllRecords().Where(or => or.OrderID == id).FirstOrDefault());
            return Json(id);
        }
    }
}
