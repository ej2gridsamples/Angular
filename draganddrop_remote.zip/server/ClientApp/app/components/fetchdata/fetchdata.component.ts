import { Component, ViewChild, ViewEncapsulation, OnInit, Inject } from '@angular/core';
import { DatePicker } from '@syncfusion/ej2-calendars';
import { Column, EditSettingsModel, ToolbarItems, IEditCell } from '@syncfusion/ej2-angular-grids';
import { DataManager, WebApiAdaptor, UrlAdaptor } from '@syncfusion/ej2-data';
import { SaveEventArgs, IRow } from '@syncfusion/ej2-grids';
import { Ajax } from '@syncfusion/ej2-base';

import { GridComponent, RowDropEventArgs } from '@syncfusion/ej2-angular-grids';
import { employeeData, customerData, orderData, orderDatas } from './datasource';

@Component({
    selector: 'fetchdata',
    templateUrl: './fetchdata.component.html',
    encapsulation: ViewEncapsulation.Emulated
})
export class FetchDataComponent {
  public data: any;
  @ViewChild('grid')
  public grid: GridComponent;
  public selectOptions: Object;

    ngOnInit(): void {
    this.selectOptions = { type: 'Multiple' };
    this.data = new DataManager({
      url: 'api/Orders',
      adaptor: new WebApiAdaptor
    });
    }

    rowDrop(args: RowDropEventArgs) {
        var ajax = new Ajax();
        ajax.type = "POST"
        ajax.url = "api/Orders/Move"
        var moveposition = { oldIndex: args.fromIndex, newIndex: args.dropIndex  };
        ajax.data = JSON.stringify(moveposition);
        ajax.send();
        ajax.onSuccess = ()=> {
            this.grid.refresh();
        }
    }

}

