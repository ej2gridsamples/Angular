import { Component, OnInit } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements OnInit {
  public data: Object[];

  constructor(public navCtrl: NavController) {

  }

  ngOnInit(){
    this.data = [
      { OrderID: 10248, CustomerID: 'VINET', Freight: 32.38, ShipCountry: 'France', ShipAddress: 'Carrera 22 con Ave. Carlos Soublette #8-35'},
      { OrderID: 10249, CustomerID: 'TOMSP', Freight: 11.61, ShipCountry: ' Germany', ShipAddress: 'Sierras de Granada 9993' },
      { OrderID: 10250, CustomerID: 'HANAR', Freight: 65.83, ShipCountry: 'Brazil', ShipAddress: 'Mehrheimerstr. 369' },
      { OrderID: 10251, CustomerID: 'VICTE', Freight: 41.34, ShipCountry: 'France',ShipAddress: 'Que Delícia' },
      { OrderID: 10252, CustomerID: 'SUPRD', Freight: 51.3, ShipCountry: 'Belgium',ShipAddress: 'Rattlesnake Canyon Grocery' },
      { OrderID: 10253, CustomerID: 'HANAR', Freight: 58.17, ShipCountry: 'Brazil',ShipAddress:'Kirchgasse 6' },
      { OrderID: 10254, CustomerID: 'CHOPS', Freight: 22.98, ShipCountry: 'Switzerland' ,ShipAddress:'Åkergatan 24'},
      { OrderID: 10255, CustomerID: 'RICSU', Freight: 148.33, ShipCountry: 'Switzerland',ShipAddress:'24, place Kléber' },
      { OrderID: 10256, CustomerID: 'SUPRD', Freight: 13.97, ShipCountry: 'Brazil' ,ShipAddress:'Torikatu 38'},
      { OrderID: 10257, CustomerID: 'WELLI', Freight: 14.23, ShipCountry: 'Venezuela' ,ShipAddress:'Berliner Platz 43'},
      { OrderID: 10258, CustomerID: 'VICTE', Freight: 18.33, ShipCountry: 'France',ShipAddress:'5ª Ave. Los Palos Grandes' },
      { OrderID: 10259, CustomerID: 'WELLI', Freight: 28.13, ShipCountry: 'Brazil' ,ShipAddress:'1029 - 12th Ave. S.'},
      { OrderID: 10260, CustomerID: 'CHOPS', Freight: 48.34, ShipCountry: 'Switzerland' ,ShipAddress:'Torikatu 38' },
      { OrderID: 10261, CustomerID: 'SUPRD', Freight: 32.73, ShipCountry: ' Germany' ,ShipAddress:'P.O. Box 555'},
      { OrderID: 10262, CustomerID: 'TOMSP', Freight: 12.31, ShipCountry: 'Switzerland',ShipAddress:'2817 Milton Dr.' },
      { OrderID: 10263, CustomerID: 'VICTE', Freight: 23.77, ShipCountry: 'Brazil',ShipAddress:'Taucherstraße 10'},
      { OrderID: 10264, CustomerID: 'SUPRD', Freight: 43.47, ShipCountry: 'Venezuela',ShipAddress:'59 rue de l Abbaye'},
      { OrderID: 10265, CustomerID: 'CHOPS', Freight: 53.37, ShipCountry: 'Belgium',ShipAddress:'Via Ludovico il Moro 22'},
    ];
  }

}
